<?php
class Livechat_Livechat_Block_Livechat extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
}