<?php

class Livechat_Livechat_IndexController extends Mage_Core_Controller_Front_Action
{
}